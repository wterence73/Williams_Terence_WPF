/*
 Terence Williams
 WPF 1408 Section 01
 Expressions Assignment
 11-06-14
 */

//Create a js for implied depreciation for a retail company

//Greet the User
//Alert the user
alert("Welcome to The Willis Trade Company");

//Ask the name of the user

var userName = prompt("What is your name?");

//Console.log out the response
console.log(userName)

//Begin exercise
alert("Let's begin our depreciation exercise");

//Array

alert("Sofa cost divided by the term=")

var sofa  = [250, 68];

var total = sofa[0] / sofa[1]
console.log(total);
alert(total)

//Alert user total
alert ("Your depreciation is an estimated $3.68");

//Alert user about turning depreciation into weekly gross margin
alert ("We will now turn depreciation into weekly gross margin ");

//Create a variable for Rate

var weeklyRate = 13.99;

//Create a variable for Depreciation

var weeklyDepreciation = 3.68;

//Calculate grossMargin

alert("Weekly cost - weekly depreciation =")

var grossMargin = weeklyRate - weeklyDepreciation ;
console.log(grossMargin) ;

//Alert user their grossMargin

var grossMargin = weeklyRate - weeklyDepreciation +  "Dollars"
alert(grossMargin)

//Ask user if they would like to know the potential rental revenue on the product

var potentialRevenue = prompt("Would you like to know the potential revenue?");

//Console.log out the response
console.log(potentialRevenue)

//Create variable for weekly cost

var weeklyRate = 13.99

//Create variable for term on rent

var term = 68

//Calculate total potential revenue

var potentialRevenue = weeklyRate * term;
console.log(potentialRevenue);

//Alert user with their total revenue

var potentialRevenue = weeklyRate * term +  "Dollars"
alert(potentialRevenue)

//Inform user about understanding implied depreciation
alert("Understanding implied depreciation will net you some very good income potential");

//Get user feedback

var userFeedback = prompt("Did you enjoy the exercise?");

//Console.log out the response
console.log(userFeedback);

alert("Thank you for participating");































