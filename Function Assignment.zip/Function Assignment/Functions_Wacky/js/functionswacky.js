/**
 Terence Williams
 Functions Assignment
 Personal
 11/19/2014
 */

//Create 
